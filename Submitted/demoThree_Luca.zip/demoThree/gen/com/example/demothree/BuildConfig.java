/** Automatically generated file. DO NOT MODIFY */
package com.example.demothree;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}