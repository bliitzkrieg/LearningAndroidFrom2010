package com.example.assignmentsix;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;


public class ActivityTwo extends Activity {

	String currentImage;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        
        Intent intent = getIntent();
        currentImage = intent.getStringExtra("image");
		
        ImageView img = (ImageView) findViewById(R.id.imageTwo);	
       
        if(currentImage.equals("success")){
        	img.setImageResource(R.drawable.success);
        }
        else if(currentImage.equals("firstworld")){
        	img.setImageResource(R.drawable.firstworld);
        }
        else if(currentImage.equals("onedoesnot")){
        	img.setImageResource(R.drawable.onedoesnot);
        }
        else if(currentImage.equals("overattached")){
        	img.setImageResource(R.drawable.overattached);   
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_main2, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
    	Toast toast;
    	Context context = getApplicationContext();
    	switch (item.getItemId()){
    	case R.id.help:
    		toast = Toast.makeText(context, "Help not yet implemented", Toast.LENGTH_SHORT);
    		toast.show();
    	return true;
    	case R.id.next:
    		toast = Toast.makeText(context, "Next not yet implemented", Toast.LENGTH_SHORT);
    		toast.show();
    	return true;
    	case R.id.signup:
    		toast = Toast.makeText(context, "Sign up not yet implemented", Toast.LENGTH_SHORT);
    		toast.show();
    	return true;
    	default:
    		return super.onOptionsItemSelected(item);
    	}
    }
    
    
    
}
