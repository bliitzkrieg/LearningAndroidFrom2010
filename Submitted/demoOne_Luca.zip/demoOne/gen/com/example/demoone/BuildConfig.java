/** Automatically generated file. DO NOT MODIFY */
package com.example.demoone;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}